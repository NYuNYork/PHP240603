<?php 
    $title = "Főoldal";
    include("includes/dbcon.php");
    include("includes/sql.php");
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sablon - <?php if(isset($title)) { echo $title; } ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/mystyle.css">
    <!-- Font Awesome Solid + Brands -->
    <link href="assets/fontawesome/css/fontawesome.css" rel="stylesheet">
    <link href="assets/fontawesome/css/solid.css" rel="stylesheet">
    <script src="assets/js/bootstrap.bundle.js"></script>
</head>
<body class="bg-light">
    <div class="container-fluid bg-dark">
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark container px-3">    
          <i class="fa-solid fa-burger me-2"></i><a class="navbar-brand" href="./">Szendvicsek</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="elso.php">Első oldal</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="masodik.php">Második oldal</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="harmadik.php">Harmadik oldal</a>
              </li>  
            </ul>
          </div>
        </nav>
    </div>