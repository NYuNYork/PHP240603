<?php
    function Connect(){
        $szerver    = "localhost";
        $user       = "root";
        $pass       = "";
        $dbname     = "szendvics2";

        $con = mysqli_connect($szerver, $user, $pass, $dbname);

        if(!$con){
            die("Nem sikerült csatlakozni");
        }

        return $con;
    }
?>