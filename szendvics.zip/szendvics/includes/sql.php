<?php 
    function All(){
        $con = Connect();
        $sql = "SELECT * FROM termekek";
        $result = mysqli_query($con, $sql);
        return $result;
        mysqli_close();
    }

    function Single($id){
        $con = Connect();
        $sql = "SELECT * FROM termekek WHERE szendvics_id = ".$id;
        $result = mysqli_query($con,$sql);
        return $result;
        mysqli_close();
    }

?>