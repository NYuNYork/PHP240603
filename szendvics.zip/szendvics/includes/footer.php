<footer class="container text-center">
        <hr>
        <p>Digruber Eszter 12.B</p>
    </footer>
</body>
</html>