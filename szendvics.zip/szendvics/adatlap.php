<?php
    include("includes/header.php");
    $title = "menü";
    if(isset($_GET["id"])){
        $id = $_GET["id"];
        $result = Single($id);
        $row = mysqli_fetch_array($result); 
    }
?>

<main class="container">
    <section class="pt-3">
        <h2 class="pt-2"><?php echo $row["nev"]; ?></h2>
    <p>Kenyértipus: <?php echo $row["kenyertipus"];?></p>
    <p>Szendics leírása: <?php echo $row["leiras"];?></p>
    <p>ár: <?php echo $row["ar"];?></p>
</main>

<?php 
    include("includes/footer.php")
?>