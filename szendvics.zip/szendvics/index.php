<?php 
    include("includes/header.php");
    $result = All();
    $title = "Menü";
?>

<main class="container">
    <section class="pt-3">
        <h2 class="pt-2">Szendvicsek - Menü</h2>
        <table class="table table-striped table-bordered">
            <tr>
                <th>ID</th>
                <th>Név</th>
                <th>Kenyértípus</th>
                <th>Leírás</th>
                <th>Ár</th>
            </tr>
            <?php while($row = mysqli_fetch_array($result)){ ?>
                <tr>
                    <td><?php echo $row["szendvics_id"]; ?></td>
                    <td>
                        <a href="adatlap.php?id=<?php echo $row["szendvics_id"]; ?>"> 
                            <?php echo $row["nev"]; ?>

                        </a>
                    </td>

                    <td><?php echo $row["nev"]; ?></td>
                    <td><?php echo $row["kenyertipus"]; ?></td>
                    <td><?php echo $row["leiras"]; ?></td>
                    <td><?php echo $row["ar"]; ?></td>
                </tr>
            <?php } ?>
        </table>
    </section>
</main>


<?php 
    include("includes/footer.php");
?>
